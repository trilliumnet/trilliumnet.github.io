main()
{
print("hi mom\n");
}
